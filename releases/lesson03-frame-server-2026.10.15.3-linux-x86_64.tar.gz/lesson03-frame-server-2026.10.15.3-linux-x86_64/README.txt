第三课帧同步 Linux Server；BMAP-only，Unity 单独交付。
从解压根目录启动（两个终端；先等 Battle READY）：
cd server
./third_party/skynet/skynet config/frame_battle_process.lua
./third_party/skynet/skynet config/frame_gateway_process.lua
在各终端按 Ctrl-C 停止。监听为本机 127.0.0.1:19021；Cluster 2537/2538。
系统依赖见 release_manifest.json；发布不包含编译工具或测试客户端。
