第三课帧同步 Linux Server；BMAP-only，Unity 单独交付。

从解压目录执行以下命令（需要在 Linux/WSL 中运行）：
  ./server/run_server.sh start    后台启动 Battle；READY 后再启动 Gateway
  ./server/run_server.sh status   查看 Battle/Gateway 状态
  ./server/run_server.sh stop     通过 shutdownctl 优雅停止 Gateway，再停止 Battle
  ./server/run_server.sh restart  按上述顺序停止并重新启动
  ./server/run_server.sh doctor   检查 Skynet、配置和关闭控制依赖

首次部署不需要执行 prepare 或 build：打包时已经准备发布资产并构建 Native 运行依赖。
进程 PID 文件位于 server/run/lesson3_frame_sync/；标准输出诊断日志位于 server/logs/lesson3_frame_sync/；FlyWow 业务日志分别位于 server/logs/frame_battle/ 与 server/logs/frame_gateway/。
Battle/Cluster 配置见 config/frame_sync.lua；Gateway 监听配置见 config/gateway_frame_sync.lua。
系统依赖见 release_manifest.json；不包含编译工具、LuaPanda或测试客户端。
