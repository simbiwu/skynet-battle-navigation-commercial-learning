-- 职责：由 proto CommandId 和 Request/Response 消息生成的 FlyWow Gateway command registry。
-- 边界：Build Artifact；运行时只读加载，不手工注册 command。
-- 输入/输出：CommandId + 可选 XxxRequest/XxxResponse -> Envelope command 映射。
-- 生命周期：协议生成后随 Server 产物发布；Gateway 启动时加载并校验。
-- 不负责：不实现业务 handler、不读取 Socket、不动态解析 .proto。
local command_ids =
    {
        FRAME_INPUT = 1102,
        FRAME_JOIN = 1101,
        FRAME_LEAVE = 1105,
        FRAME_PUSH = 1103,
        FRAME_RECOVER = 1104,
        FRAME_REPLAY = 1106,
        QUERY_CELL = 1001,
        RUN_AUTO_BATTLE = 1002,
        STATE_CAST = 1203,
        STATE_INPUT = 1202,
        STATE_JOIN = 1201,
        STATE_LEAVE = 1207,
        STATE_PUSH = 1204,
        STATE_RECOVER = 1205,
        STATE_REPLAY = 1208,
        STATE_RESYNC = 1206,
    }
return
{
    envelope_type = ".battle.navigation.v1.Envelope",
    command_ids   = command_ids,
    commands      =
    {
        [command_ids.QUERY_CELL] =
        {
            name          = "QueryCell",
            request_type  = ".battle.navigation.v1.QueryCellRequest",
            response_type = ".battle.navigation.v1.QueryCellResponse",
        },
        [command_ids.RUN_AUTO_BATTLE] =
        {
            name          = "RunAutoBattle",
            request_type  = ".battle.navigation.v1.RunAutoBattleRequest",
            response_type = ".battle.navigation.v1.RunAutoBattleResponse",
        },
        [command_ids.FRAME_JOIN] =
        {
            name          = "FrameJoin",
            request_type  = ".battle.navigation.v1.FrameJoinRequest",
            response_type = ".battle.navigation.v1.FrameJoinResponse",
        },
        [command_ids.FRAME_INPUT] =
        {
            name          = "FrameInput",
            request_type  = ".battle.navigation.v1.FrameInputRequest",
            response_type = nil,
        },
        [command_ids.FRAME_PUSH] =
        {
            name          = "FramePush",
            request_type  = nil,
            response_type = ".battle.navigation.v1.FramePushResponse",
        },
        [command_ids.FRAME_RECOVER] =
        {
            name          = "FrameRecover",
            request_type  = ".battle.navigation.v1.FrameRecoverRequest",
            response_type = ".battle.navigation.v1.FrameRecoverResponse",
        },
        [command_ids.FRAME_LEAVE] =
        {
            name          = "FrameLeave",
            request_type  = ".battle.navigation.v1.FrameLeaveRequest",
            response_type = ".battle.navigation.v1.FrameLeaveResponse",
        },
        [command_ids.FRAME_REPLAY] =
        {
            name          = "FrameReplay",
            request_type  = ".battle.navigation.v1.FrameReplayRequest",
            response_type = ".battle.navigation.v1.FrameReplayResponse",
        },
        [command_ids.STATE_JOIN] =
        {
            name          = "StateJoin",
            request_type  = ".battle.navigation.v1.StateJoinRequest",
            response_type = ".battle.navigation.v1.StateJoinResponse",
        },
        [command_ids.STATE_INPUT] =
        {
            name          = "StateInput",
            request_type  = ".battle.navigation.v1.StateInputRequest",
            response_type = ".battle.navigation.v1.StateInputResponse",
        },
        [command_ids.STATE_CAST] =
        {
            name          = "StateCast",
            request_type  = ".battle.navigation.v1.StateCastRequest",
            response_type = ".battle.navigation.v1.StateCastResponse",
        },
        [command_ids.STATE_PUSH] =
        {
            name          = "StatePush",
            request_type  = nil,
            response_type = ".battle.navigation.v1.StatePushResponse",
        },
        [command_ids.STATE_RECOVER] =
        {
            name          = "StateRecover",
            request_type  = ".battle.navigation.v1.StateRecoverRequest",
            response_type = ".battle.navigation.v1.StateRecoverResponse",
        },
        [command_ids.STATE_RESYNC] =
        {
            name          = "StateResync",
            request_type  = ".battle.navigation.v1.StateResyncRequest",
            response_type = ".battle.navigation.v1.StateResyncResponse",
        },
        [command_ids.STATE_LEAVE] =
        {
            name          = "StateLeave",
            request_type  = ".battle.navigation.v1.StateLeaveRequest",
            response_type = ".battle.navigation.v1.StateLeaveResponse",
        },
        [command_ids.STATE_REPLAY] =
        {
            name          = "StateReplay",
            request_type  = ".battle.navigation.v1.StateReplayRequest",
            response_type = ".battle.navigation.v1.StateReplayResponse",
        },
    },
}
