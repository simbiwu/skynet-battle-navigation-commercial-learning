--- 职责：提供可被业务 require 的 Navigation 入口与编辑器可识别的公开合同。
--- 边界：普通 Lua 模块；不创建 Service、不启动进程、不负责地图发布门禁。
--- 生命周期：每个 Lua State require 缓存此模块；静态地图由 Native 进程 Registry 持有。
--- Native 查询同步且不 yield；同一 Context 只允许其 owner 顺序调用。

---@class FlyWowNavigationPosition
---@field x_mm integer 世界 X，整数毫米；调用方持有的纯数据。
---@field y_mm integer 世界高度 Y，整数毫米；地面移动由地图归一化，空中由调用方指定。
---@field z_mm integer 世界 Z，整数毫米；不是 Grid 下标。

---@class FlyWowNavigationError
---@field code string 稳定机器错误码；按此字段分支，不解析文案。
---@field position? FlyWowNavigationPosition 空中推进预算失败时最后提交位置；其它错误可无此字段。
---@field message string 诊断上下文；只用于日志，不进入业务判断。

---@class FlyWowNavigationProfile
---@field unit_id integer 通用 Unit 类型 ID；Registry 按该 ID 排序并二分查找。
---@field radius_mm integer 非负体型半径，毫米；静态/动态 footprint 共同使用。
---@field max_step_mm integer 非负最大跨格高度差，毫米。
---@field max_slope_permille integer 非负坡度上限；1000 表示高差等于水平距离。
---@field area_cost_permille? table<integer,integer> Area 0..255 成本；未配置默认 1000。
---@field area_allowed? table<integer,boolean> Area 0..255 通行开关；未配置使用 Native 默认。

---@class FlyWowNavigationPath
---@field status fun(self:FlyWowNavigationPath):string 查询终点 reached/partial；不是推进状态。
---@field count fun(self:FlyWowNavigationPath):integer 点数；只读、不 yield。
---@field world_point fun(self:FlyWowNavigationPath,index:integer):FlyWowNavigationPosition 下标从 1 开始；越界抛错。
---@field length_mm fun(self:FlyWowNavigationPath):integer XZ 路径长度；毫米。

---@class FlyWowNavigationAdvanceRequest
---@field unit_id integer 静态 Unit 类型 ID；每次调用从当前 Registry 查询。
---@field unit_instance_id integer 当前 Battle 中实体实例的正 uint32 句柄。
---@field path FlyWowNavigationPath 此单位独占 Path/cursor，不可跨单位共享推进状态。
---@field from_world FlyWowNavigationPosition 当前权威位置，调用方拥有且只读。
---@field distance_mm integer 本 Tick 非负 uint32 距离预算，毫米。

---@class FlyWowNavigationAdvanceResult
---@field status string moving/reached/blocked；代表本次已提交的推进结果。
---@field position FlyWowNavigationPosition 最后成功提交的位置，供业务保存。
---@field consumed_mm integer 实际消费预算；毫米，不是 Tick 数。
---@field moved boolean 是否有已成功提交的 XZ 变化。

---@alias FlyWowNavigationCellRule "allow"|"block"|"default"
--- allow 允许与其他单位重叠；block 禁止重叠但空格仍可进入；default 恢复默认允许重叠行为。

---@class FlyWowNavigationAirBody
---@field radius_mm integer XZ 盒半宽，非负 uint32 毫米。
---@field half_height_mm integer Y 盒半高，非负 uint32 毫米。

---@class FlyWowNavigationAirLimits
---@field expanded? integer 展开上限，默认及最大 4096。
---@field nodes? integer touched/open 上限，默认及最大 8192。
---@field buckets? integer 重复访问桶也计数，默认及最大 8192。
---@field tests? integer 区间、候选、地形与后处理工作，默认及最大 65536。
---@field path_points? integer 路点上限，默认及最大 4096。
---@field objects? integer Context 对象上限，默认及最大 4096。
---@field object_links? integer 单对象关联上限，默认及最大 256。
---@field links? integer 总关联上限，默认及最大 262144；只能调低上述保护值。

---@class FlyWowNavigationAirPolicy
---@field check_terrain? boolean 默认 false；开启后盒底严格高于地表加 clearance。
---@field clearance_mm? integer 非负 uint32 毫米，默认 0。

---@class FlyWowNavigationAirSetRequest
---@field handle integer Context 内正整数句柄；业务 owner 管理其生命周期。
---@field min FlyWowNavigationPosition 闭合 AABB 下界；XZ 在地图内。
---@field max FlyWowNavigationPosition 闭合 AABB 上界；任意矩形尺寸。

---@class FlyWowNavigationAirRemoveRequest
---@field handle integer Context 内正整数句柄；不存在也成功。

---@class FlyWowNavigationAirSweepRequest:FlyWowNavigationAirPolicy
---@field from FlyWowNavigationPosition 段起点中心，调用方只读纯数据。
---@field to FlyWowNavigationPosition 段终点中心；可改变 Y。
---@field body FlyWowNavigationAirBody 本次查询体积。
---@field exclude_handle? integer 仅排除此动态对象，默认不排除。

---@class FlyWowNavigationAirFindRequest:FlyWowNavigationAirPolicy
---@field start FlyWowNavigationPosition 起点 XZ；查询使用 flight_y_mm 作为 Y。
---@field target FlyWowNavigationPosition 目标 XZ；查询使用 flight_y_mm 作为 Y。
---@field flight_y_mm integer 本路径固定 int64 高度，不自动选择爬升高度。
---@field body FlyWowNavigationAirBody 路径保存此体积；推进时匹配注册尺寸。
---@field exclude_handle? integer 排除自身动态句柄。
---@field range_mm? integer 非负 uint32 XZ 中心距离；0 精确终点，默认 0。

---@class FlyWowNavigationAirMoveRequest:FlyWowNavigationAirPolicy
---@field handle integer 已注册对象句柄。
---@field target FlyWowNavigationPosition 新中心；完整连续扫掠通过后才提交。

---@class FlyWowNavigationAirAdvanceRequest:FlyWowNavigationAirPolicy
---@field handle integer 已注册对象句柄；与 Path/cursor 一起由单 owner 顺序使用。
---@field path FlyWowNavigationPath 同地图快照的空中路径；不可跨对象共享推进 cursor。
---@field distance_mm integer 非负 uint32 折线步长；后段失败保留已提交部分。

---@class FlyWowNavigationAirSweepResult
---@field kind "clear"|"static"|"dynamic" 同时接触静态优先，再按格或句柄排序。
---@field handle integer 动态首命中句柄；其它类别为 0。
---@field cell_index integer 静态格诊断下标；不是长期业务身份。
---@field time_numerator string 十进制 uint64 分子，避免 Lua 有符号整数丢范围。
---@field time_denominator string 十进制 uint64 正分母；段参数为两者之比。

---@class FlyWowNavigationContext
---@field set_air_obstacle fun(self:FlyWowNavigationContext,request:FlyWowNavigationAirSetRequest):boolean?,FlyWowNavigationError? 状态设置不表示扫掠；失败旧索引完整。
---@field remove_air_obstacle fun(self:FlyWowNavigationContext,request:FlyWowNavigationAirRemoveRequest):boolean?,FlyWowNavigationError? 幂等释放本 Context 对象。
---@field find_air_path fun(self:FlyWowNavigationContext,request:FlyWowNavigationAirFindRequest):FlyWowNavigationPath?,FlyWowNavigationError? 固定高度八邻接规划，动态变化后移动仍重验。
---@field sweep_air fun(self:FlyWowNavigationContext,request:FlyWowNavigationAirSweepRequest):FlyWowNavigationAirSweepResult?,FlyWowNavigationError? 连续盒体只读查询；预算错误不伪装 clear。
---@field move_air fun(self:FlyWowNavigationContext,request:FlyWowNavigationAirMoveRequest):FlyWowNavigationPosition?,FlyWowNavigationError? 全成或全不成，保留原 AABB 尺寸。
---@field advance_air_path fun(self:FlyWowNavigationContext,request:FlyWowNavigationAirAdvanceRequest):FlyWowNavigationAdvanceResult?,FlyWowNavigationError? blocked 返回合法前缀；预算错误的 error.position 为已提交位置。
---@field set_cell_rule fun(self:FlyWowNavigationContext,grid_x:integer,grid_z:integer,rule:FlyWowNavigationCellRule):boolean?,FlyWowNavigationError? 运行时设置当前 Battle 的单格重叠规则；default 清除覆盖。
---@field find_path fun(self:FlyWowNavigationContext,unit_id:integer,start:FlyWowNavigationPosition,goal:FlyWowNavigationPosition,unit_instance_id:integer,allow_partial?:boolean):FlyWowNavigationPath?,FlyWowNavigationError?
---@field find_path_to_range fun(self:FlyWowNavigationContext,unit_id:integer,start:FlyWowNavigationPosition,target:FlyWowNavigationPosition,range_mm:integer,unit_instance_id:integer,allow_partial?:boolean):FlyWowNavigationPath?,FlyWowNavigationError? 以目标中心为圆心的通用导航范围查询，不代表战斗攻击规则。
---@field find_path_to_unit_range fun(self:FlyWowNavigationContext,mover_unit_id:integer,start_world:FlyWowNavigationPosition,target_unit_id:integer,target_world:FlyWowNavigationPosition,unit_instance_id:integer,allow_partial?:boolean):FlyWowNavigationPath?,FlyWowNavigationError? 双方导航半径限定不可重叠距离，Grid 对角线容差适配离散终点；不读取攻击距离。
---@field place_unit fun(self:FlyWowNavigationContext,unit_id:integer,unit_instance_id:integer,position:FlyWowNavigationPosition):FlyWowNavigationPosition?,FlyWowNavigationError?
---@field move_unit fun(self:FlyWowNavigationContext,unit_id:integer,unit_instance_id:integer,from_world:FlyWowNavigationPosition,to_world:FlyWowNavigationPosition):FlyWowNavigationPosition?,FlyWowNavigationError?
---@field release_unit fun(self:FlyWowNavigationContext,unit_instance_id:integer):boolean?,FlyWowNavigationError?
---@field advance_path fun(self:FlyWowNavigationContext,request:FlyWowNavigationAdvanceRequest):FlyWowNavigationAdvanceResult?,FlyWowNavigationError?
---@field unit_radius_mm fun(self:FlyWowNavigationContext,unit_id:integer):integer?,FlyWowNavigationError? 读取当前 Registry 中该 Unit 类型的导航半径。
---@field map_version fun(self:FlyWowNavigationContext):integer?,FlyWowNavigationError? 读取 Context 固定地图的资产版本。
---@field cell_size_mm fun(self:FlyWowNavigationContext):integer?,FlyWowNavigationError?
---@field close fun(self:FlyWowNavigationContext) 幂等释放大块 Context 内存，无返回值；GC 兜底析构 userdata。

---@class FlyWowNavigationIdentity
---@field map_id integer BMAP 实际地图身份；不能忽略并只相信输入文件名。
---@field map_version integer BMAP 实际内容版本；不可用 format_version 代替。

---@class FlyWowNavigationCell
---@field grid_x integer 当前 Grid 的调试列下标；不是长期位置合同。
---@field grid_z integer 当前 Grid 的调试行下标。
---@field cell_height_mm integer 地表高度，整数毫米。
---@field area integer 稳定地表编码；不是 Unity NavMesh Area 下标。
---@field clearance integer 静态保守格距；单位 Cell，动态单位不重算此值。
---@field walkable boolean 静态 Walkable bit；不代表所有 Agent 都能站立。

---@class FlyWowNavigationModule
---@field load_navigation_profiles fun(profiles:FlyWowNavigationProfile[]):boolean?,FlyWowNavigationError? 校验并原子替换进程当前导航配置；已有 Context 下一次调用即使用新表。
---@field load_map fun(path:string,airnav_path?:string):FlyWowNavigationIdentity?,FlyWowNavigationError? 加载并按 map_id 替换当前地图；执行文件 I/O；已有 Context 保留旧地图。
---@field query_cell fun(map_id:integer,map_version:integer,position:FlyWowNavigationPosition):FlyWowNavigationCell?,FlyWowNavigationError? 只读同步查询；Registry 查找短锁。
---@field new_context fun(map_id:integer,air_limits?:FlyWowNavigationAirLimits):FlyWowNavigationContext?,FlyWowNavigationError? 固定当前地图并分配私有 scratch/occupancy；不缓存 Profile，返回调用方独占 userdata.

--- Lua 对外入口：把稳定的 FlyWow Navigation 合同转交给 Native 实现。
---
--- 业务代码通过 require "flywow_navigation" 加载本文件。
--- 本文件不重复实现 BMAP、Grid、A*、smoothing 或动态占用。
---
--- 在 Server 根目录执行 ./scripts/linux/run_server.sh build 后生成：
---   third_party/skynet-flywow/build/native/flywow_navigation_native.so
--- 宿主 process config 直接把该目录写入 lua_cpath；无需生成路径配置文件。
--- require 先命中本 Lua Wrapper，再由不同模块名加载 C++ Native。
---@type FlyWowNavigationModule
local navigation = require "flywow_navigation_native"
return navigation
