第三课帧同步 Linux Server；BMAP-only，Unity 单独交付。
从解压根目录进入 server/；两个终端按顺序启动，先等 Battle READY：
./third_party/skynet/skynet config/frame_battle_process.lua
./third_party/skynet/skynet config/frame_gateway_process.lua
各终端按 Ctrl-C 停止。
监听及 Cluster 地址见 config/frame_sync.lua。
系统依赖见 release_manifest.json；不包含编译工具、LuaPanda或测试客户端。
